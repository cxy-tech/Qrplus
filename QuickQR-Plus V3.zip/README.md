# QuickQR Plus

Static HTML/CSS/JavaScript QR toolkit. Photo-to-QR uploads a compressed JPEG to Supabase Storage and encodes the public image URL into the QR, so other devices can open it.

## Supabase setup (required for Photo-to-QR)
1. Create a project at https://supabase.com/.
2. In Project Settings > API, copy the Project URL and `anon`/publishable key.
3. Edit `supabase-config.js` and replace `YOUR_SUPABASE_PROJECT_URL` and `YOUR_SUPABASE_ANON_KEY`.
4. Open Supabase SQL Editor and run `supabase-setup.sql`.
5. Deploy/host the website over HTTPS. Test by uploading a photo and scanning the QR from another device.

The browser uses only the Supabase anon/publishable key. Never put a `service_role` key in frontend files. The included SQL allows anonymous uploads to a public bucket, which is simple for a static demo but can be abused; for a public production site, add authentication, rate limiting, or a server-side upload function.

## URL QR
The Link or URL type supports website links and common app/deep links. A domain pasted without a scheme is automatically treated as HTTPS. Dangerous browser schemes such as `javascript:`, `data:`, `file:`, and `blob:` are blocked.

## Landing page and generator navigation
- The landing page is the default view.
- Clicking any **Create QR** call-to-action opens the QR generator and tools workspace.
- Use **Back to home** in the mobile hamburger menu or click the brand to return to the landing page.
- The feature cards, steps, and FAQ use responsive layouts for desktop and mobile.


## V3 landing page and tool upgrades
- Added use-case cards, privacy information, release/update section, and extra navigation links.
- Added QR type search/filtering, foreground/background color controls, and a built-in template library.
- Added history favorites and JSON export/import backup.
- Added responsive layouts for the new sections and controls.
- Dynamic QR redirects, analytics, cloud synchronization, hosted files, real-time threat reputation checks, and server-enforced expiration still require a backend or external service.
- Added design showcase cards that apply classic, violet, and midnight presets.
- Added contrast-ratio warnings and a confirmation before opening scanned links.
- Added local favorite marking for QR history entries.


## V3.2 template library and landing-page builder
- Removed the Save Design Preset and Load Preset controls. Use the built-in Template Library instead.
- Added six starter templates: Classic Link, Violet Brand, Midnight, Business Card, Guest Wi-Fi, and Event / School. Templates apply a QR type, frame, size, and color pair.
- Added Sticker Label, Corner Brackets, Gradient Frame, and Ticket Frame styles alongside existing frame styles.
- QR history stores the selected frame, QR size, foreground/background colors, and center logo so Reuse can restore those settings. PNG/SVG exports now include the selected frame treatment.
- Added a static Landing Page Builder with title, description, CTA, destination URL, optional logo URL, theme choices, live preview, and standalone HTML export.
- The landing-page builder does not host/publish the HTML. Upload the exported HTML to a hosting provider before creating a URL QR that points to it.
- Use a full `https://` or `http://` URL for the landing page CTA and logo.

## V3.4 Help Center and template update
- Removed the Page Builder tab and its workspace section.
- Removed the Product Updates section from the landing page.
- Expanded the visual Template Library to 12 presets: Classic Link, Violet Brand, Midnight, Business Card, Guest Wi-Fi, Event / School, Emerald Fresh, Rose Pop, Ocean Blue, Golden Hour, Lavender Soft, and Mono Pro.
- Added a floating Help Center chatbot with quick troubleshooting topics for QR generation, scanning, Photo-to-QR, and bug reports.
- Bug reports are stored locally in the current browser only. Use **Copy bug report** to copy a report for sharing; the chatbot does not automatically send reports to the developer or a server.
- Kept the existing Supabase configuration file and setup SQL unchanged.


## V3.5 Business Pro
- Added the Business Pro contact QR preset with a corporate navy and ice-blue palette, 512px QR size, and corner-frame style.

## V3.6 Program-Based Help Center
- Removed AI-powered wording and removed the OpenAI server endpoint. The chatbot now uses built-in keyword rules and predefined troubleshooting guidance; no AI API key or AI billing is needed.
- Added a **Message developer** action in the Help Center. It opens the user's email app with a pre-filled support request addressed to Cris Cortez (`seancortez0826@gmail.com`). The user must send the email from their own email app.
- Bug reports are still stored in the current browser and can be copied. They are not automatically uploaded or sent.
- Preserved the existing Supabase configuration and setup SQL.


## Version 3.7 — Electric Blue UI and installation improvements

- Updated the interface to a high-contrast Electric Blue light theme by default.
- Replaced decorative Unicode icon characters with inline Lucide-style SVG icons that remain available offline.
- Renamed the generator workspace tab from “Create QR” to “Generate”.
- Kept both the home logo and “Back to home” navigation available in the generator workspace.
- Improved the Install app button: it explains browser installation steps when the browser does not provide an install prompt, and reports installation outcomes.
- Updated PWA theme colors, app icon, stylesheet cache-busting, and service-worker cache version.
- Existing QR generation, scan, bulk, history, templates, Help Center, developer email, and Supabase configuration are retained.


## Version 3.8 — Electric Blue accessible UI refresh

- Removed the Install app button and its installation prompt UI.
- Removed the duplicate Create QR action from the header and placed the primary Create QR action in the hero section.
- Kept Back to home inside the mobile hamburger menu.
- Improved contrast and readability for the Help Center, dynamically generated inputs, form controls, and supporting text.
- Expanded the horizontal Template Library to 23 templates to reduce vertical scrolling.
- Updated Help Center responses so typing “QR scanner” returns a concise overview of the scanner feature; troubleshooting wording gets separate guidance.
- Removed visible “program-based” wording from the Help Center.
- Improved the hero copy and primary/secondary calls to action.
- Preserved QR tools, Supabase configuration, setup SQL, and the developer contact email.


## V3.9 UI update
- Unified the application interface around the Electric Blue and light palette, with accessible input and dropdown contrast.
- Removed Back to Home from the hamburger tools menu (home navigation remains elsewhere).
- Removed History Import and Export controls and their event handlers.
- Changed the template library to a two-row horizontal scroller and unified template preview swatches to blue/light UI colors.
- Improved the QR Safety Link Checker safe-result visibility with a stronger green success state.
- Updated the service-worker cache version.


V4.3 palette restoration: violet accent palette with dark mode enabled by default and a saved light/dark toggle. The violet palette is applied globally across the landing page and generator interface.


## V4.15 — Reference-inspired interface refresh
- Refreshed the visual system with a clean light-first layout, softer surfaces, clear button hierarchy, and responsive cards inspired by modern QR generator workflows.
- Preserved QuickQR Plus branding and existing generator, customization, scanning, bulk export, photo QR, history, templates, and help interactions.
- The theme toggle remains available; first-time visitors now see the light theme by default.
- Dynamic QR redirects, hosted content, and analytics are not claimed unless configured through a suitable backend/service.

## Generator routes and template library update

- `/generator` opens the QR creation workspace.
- `/generator/url` opens the URL QR creation workflow directly.
- Browser back/forward navigation follows the landing and generator routes.
- Template library includes live search and category filters (All styles, Minimal, Colorful, Business, Dark, Wi-Fi).
- Vercel rewrite rules are included in `vercel.json` so these routes serve the single-page app.

This project is an independent QuickQR Plus implementation inspired by common QR-generator workflows. Third-party hosted dynamic QR redirects, subscription features, and analytics require a separately configured backend and are not provided by frontend-only routing.
