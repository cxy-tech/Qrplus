/* QuickQR Plus service worker. CDN libraries are cached after first successful online load. */
const CACHE_NAME = "quickqr-plus-v414-balanced-mobile-buttons";
const APP_FILES = ["./", "./index.html", "./style.css", "./script.js", "./supabase-config.js", "./manifest.json", "./icon.svg", "./cris-dev-logo.png"];
const LIBRARIES = [
  "https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js",
  "https://cdn.jsdelivr.net/npm/jsqr@1.4.0/dist/jsQR.js",
  "https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js",
  "https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"
];
self.addEventListener("install", event => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_NAME);
    await cache.addAll(APP_FILES).catch(() => {});
    await Promise.all(LIBRARIES.map(async url => {
      try {
        const response = await fetch(url, {mode:"cors", cache:"no-cache"});
        if (response.ok) await cache.put(url, response);
      } catch (_) { /* Keep install successful if offline; an earlier cache may still contain this library. */ }
    }));
    await self.skipWaiting();
  })());
});
self.addEventListener("activate", event => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter(k => k.startsWith("quickqr-") && k !== CACHE_NAME).map(k => caches.delete(k)));
    await self.clients.claim();
  })());
});
self.addEventListener("fetch", event => {
  const req = event.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);
  if (url.origin === self.location.origin) {
    event.respondWith((async () => {
      try {
        const response = await fetch(req, { cache: "no-cache" });
        if (response && response.ok) {
          const copy = response.clone();
          caches.open(CACHE_NAME).then(cache => cache.put(req, copy));
        }
        return response;
      } catch (_) {
        const cached = await caches.match(req);
        return cached || (req.mode === "navigate" ? await caches.match("./index.html") : Response.error());
      }
    })());
  } else if (LIBRARIES.includes(req.url)) {
    event.respondWith(caches.match(req).then(cached => cached || fetch(req).then(response => {
      if (response.ok) { const copy = response.clone(); caches.open(CACHE_NAME).then(c => c.put(req, copy)); }
      return response;
    }).catch(() => new Response("/* Library unavailable offline. Open the app online once to cache this dependency. */", {status:503,headers:{"Content-Type":"application/javascript"}}))));
  }
});