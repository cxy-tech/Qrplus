-- Run this in Supabase Dashboard > SQL Editor.
-- Creates a public bucket for images and allows anonymous image uploads.
-- Public uploads can be abused if your site is widely shared; the bucket has a 10 MB limit.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('quickqr-photos', 'quickqr-photos', true, 10485760, array['image/jpeg'])
on conflict (id) do update set public = true, file_size_limit = 10485760, allowed_mime_types = array['image/jpeg'];

create policy "QuickQR public can upload photos"
on storage.objects for insert to anon
with check (bucket_id = 'quickqr-photos');

create policy "QuickQR public can view photos"
on storage.objects for select to anon
using (bucket_id = 'quickqr-photos');
