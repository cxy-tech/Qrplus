window.QUICKQR_SUPABASE = {
  url: "https://guynjiwrmzervvfxzrmu.supabase.co",
  anonKey: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imd1eW5qaXdybXplcnZ2Znh6cm11Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTE5Mjk2MTMsImV4cCI6MjEwNzUwNTYxM30.OGVW3oOUx0pPiFXVu39-7d7tTDPZ-s6Gn-j5zNzwQtY",
  bucket: "photos"
};