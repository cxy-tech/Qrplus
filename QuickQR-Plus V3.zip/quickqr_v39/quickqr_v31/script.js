(() => {
  "use strict";
  const $ = (id) => document.getElementById(id);
  // Inline Lucide-style SVG icons keep the interface crisp and available offline.
  const iconPaths = {
    "qr-code": '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><path d="M14 14h3v3h-3zM20 14v2M14 20h2M19 19h2v2h-2z"/>',
    "sparkles": '<path d="m12 3 1.9 5.8L20 11l-6.1 2.2L12 19l-1.9-5.8L4 11l6.1-2.2L12 3Z"/><path d="m19 14 1.1 2.9L23 18l-2.9 1.1L19 22l-1.1-2.9L15 18l2.9-1.1L19 14ZM5 2l.8 2.2L8 5l-2.2.8L5 8l-.8-2.2L2 5l2.2-.8L5 2Z"/>',
    "scan-line": '<path d="M4 7V5a1 1 0 0 1 1-1h2M17 4h2a1 1 0 0 1 1 1v2M20 17v2a1 1 0 0 1-1 1h-2M7 20H5a1 1 0 0 1-1-1v-2M4 12h16"/>',
    "layers": '<path d="m12 3 9 5-9 5-9-5 9-5Z"/><path d="m3 12 9 5 9-5M3 16l9 5 9-5"/>',
    "history": '<path d="M3 12a9 9 0 1 0 2.6-6.4L3 8"/><path d="M3 3v5h5M12 7v5l3 2"/>',
    "sun": '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.42 1.42M17.65 17.65l1.42 1.42M2 12h2M20 12h2M4.93 19.07l1.42-1.42M17.65 6.35l1.42-1.42"/>',
    "moon": '<path d="M20.9 13A8.5 8.5 0 0 1 11 3.1 8.5 8.5 0 1 0 20.9 13Z"/>',
    "download": '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m7 10 5 5 5-5M12 15V3"/>',
    "link": '<path d="M10 13a5 5 0 0 0 7.1 0l3-3A5 5 0 0 0 13 2.9l-1.7 1.7"/><path d="M14 11a5 5 0 0 0-7.1 0l-3 3A5 5 0 0 0 11 21.1l1.7-1.7"/>',
    "type": '<path d="M4 7V4h16v3M9 20h6M12 4v16"/>',
    "palette": '<path d="M12 3a9 9 0 1 0 0 18h1.5a2.5 2.5 0 0 0 1.8-4.3 1.5 1.5 0 0 1 1.1-2.6H19a2 2 0 0 0 2-2A9 9 0 0 0 12 3Z"/><circle cx="7.5" cy="10" r=".8"/><circle cx="10" cy="6.8" r=".8"/><circle cx="15" cy="7.5" r=".8"/>',
    "mail": '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>',
    "phone": '<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.4 19.4 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7l.5 2.8a2 2 0 0 1-.6 1.9L7.1 10a16 16 0 0 0 6 6l1.6-1.9a2 2 0 0 1 1.9-.6l2.8.5a2 2 0 0 1 1.6 1.9Z"/>',
    "wifi": '<path d="M5 12.5a11 11 0 0 1 14 0M8.5 16a5.5 5.5 0 0 1 7 0M12 20h.01"/><path d="M2 9a16 16 0 0 1 20 0"/>',
    "user-round": '<circle cx="12" cy="8" r="4"/><path d="M5 21a7 7 0 0 1 14 0"/>',
    "image": '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 15-5-5L5 21"/>',
    "message-square": '<path d="M21 11.5a8.4 8.4 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.4 8.4 0 0 1-3.8-.9L3 21l1.9-5.7a8.4 8.4 0 0 1-.9-3.8A8.5 8.5 0 0 1 8.7 3.9a8.4 8.4 0 0 1 3.8-.9h.5a8.5 8.5 0 0 1 8 8v.5Z"/>',
    "file-text": '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z"/><path d="M14 2v6h6M8 13h8M8 17h8"/>',
    "shield-check": '<path d="M12 22s8-4 8-11V5l-8-3-8 3v6c0 7 8 11 8 11Z"/><path d="m9 12 2 2 4-4"/>',
    "home": '<path d="m3 10 9-7 9 7"/><path d="M5 9v11h14V9M9 20v-6h6v6"/>',
    "plus": '<path d="M12 5v14M5 12h14"/>',
    "check-circle": '<circle cx="12" cy="12" r="10"/><path d="m8 12 2.5 2.5L16 9"/>',
    "search": '<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>',
    "arrow-up-right": '<path d="M7 17 17 7M7 7h10v10"/>',
    "arrow-left": '<path d="m12 19-7-7 7-7M5 12h14"/>',
    "x": '<path d="m18 6-12 12M6 6l12 12"/>'
  };
  function svgIcon(name) {
    return `<svg class="ui-icon" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${iconPaths[name] || iconPaths["qr-code"]}</svg>`;
  }
  function hydrateIcons() {
    document.querySelectorAll("[data-icon]").forEach(el => {
      const name = el.getAttribute("data-icon");
      el.innerHTML = svgIcon(name);
    });
  }
  hydrateIcons();
  const state = { type: "url", qrText: "", qrStyle: "classic", logoData: "", logoImage: null, currentName: "", history: [], stream: null, scanTimer: null, deferredPrompt: null, fg: "#000000", bg: "#ffffff" };
  const HISTORY_KEY = "quickqr-plus-history-v1";
  let selectedPhotoData = "";
  let selectedPhotoFile = null;
  let currentPhotoPublicUrl = "";
  let currentPhotoId = "";
  const BULK_LIMIT = 100;
  const MAX_HISTORY = 40;
  // Landing page / generator workspace navigation. The generator is revealed only on user action.
  const generatorApp = $("generatorApp");
  const homeNavLink = $("homeNavLink");
  function syncRoute(path, replace = false) {
    try { if (window.location.pathname !== path) window.history[replace ? "replaceState" : "pushState"]({ quickqr: true }, "", path); } catch (_) {}
  }
  function showGenerator(tab = "create", route = true) {
    document.body.classList.add("generator-mode");
    if (generatorApp) generatorApp.hidden = false;
    homeNavLink?.removeAttribute("hidden");
    if (typeof setTab === "function") setTab(tab);
    if (route) syncRoute(state.type === "url" && tab === "create" ? "/generator/url" : "/generator");
    closeMobileMenu();
    window.scrollTo({ top: 0, behavior: "smooth" });
  }
  function showLanding(route = true) {
    document.body.classList.remove("generator-mode");
    if (generatorApp) generatorApp.hidden = true;
    homeNavLink?.setAttribute("hidden", "");
    if (route) syncRoute("/");
    closeMobileMenu();
    window.scrollTo({ top: 0, behavior: "smooth" });
  }
  function loadRoute() {
    const path = window.location.pathname.replace(/\/+$/, "") || "/";
    if (path === "/generator/url") { showGenerator("create", false); setType("url"); }
    else if (path === "/generator") showGenerator("create", false);
    else showLanding(false);
  }
  window.addEventListener("popstate", loadRoute);
  document.querySelectorAll('a[href="#quickTabs"]').forEach(link => {
    link.addEventListener("click", event => { event.preventDefault(); showGenerator("create"); });
  });
  document.querySelectorAll("[data-footer-tab]").forEach(link => link.addEventListener("click", event => { event.preventDefault(); showGenerator(link.dataset.footerTab || "create"); }));
  $("workspaceHomeBtn")?.addEventListener("click", showLanding);
  homeNavLink?.addEventListener("click", event => { event.preventDefault(); showLanding(); });
  document.querySelector(".brand")?.addEventListener("click", event => {
    if (document.body.classList.contains("generator-mode")) { event.preventDefault(); showLanding(); }
  });

  const typeButtons = [...document.querySelectorAll(".type-button")];
  const tabs = [...document.querySelectorAll(".tab")];
  const contentFields = $("contentFields");
  const qrForm = $("qrForm");
  const qrContainer = $("qrCanvas");
  const qrPlaceholder = $("qrPlaceholder");
  const qrFrame = $("qrFrame");
  const downloadBtn = $("downloadBtn");
  const downloadSvgBtn = $("downloadSvgBtn");

  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  function colorLuminance(hex) {
    const raw = String(hex || "#000000").replace("#", "");
    const full = raw.length === 3 ? raw.split("").map(ch => ch + ch).join("") : raw;
    const rgb = [0,2,4].map(i => parseInt(full.slice(i,i+2),16)/255).map(v => v <= .04045 ? v/12.92 : ((v+.055)/1.055)**2.4);
    return .2126*rgb[0] + .7152*rgb[1] + .0722*rgb[2];
  }
  function qrContrastRatio(fg,bg) { const a=colorLuminance(fg), b=colorLuminance(bg); return (Math.max(a,b)+.05)/(Math.min(a,b)+.05); }
  const showMessage = (id, message, kind = "") => { const el = $(id); if (!el) return; el.textContent = message; el.className = "form-message" + (kind ? " " + kind : ""); };
  const readHistory = () => { try { const x = JSON.parse(localStorage.getItem(HISTORY_KEY) || "[]"); return Array.isArray(x) ? x : []; } catch { return []; } };
  const saveHistory = () => { try { localStorage.setItem(HISTORY_KEY, JSON.stringify(state.history.slice(0, MAX_HISTORY))); } catch { showMessage("formMessage", "Browser storage is full. This QR is still available to download.", "error"); } };
  const safeText = (id) => ($(id)?.value || "").trim();
  const escapeWifi = (s) => String(s).replace(/([\\;,:"])/g, "\\$1");

  function setTab(tab) {
    tabs.forEach(b => b.classList.toggle("active", b.dataset.tab === tab));
    ["create", "scan", "history", "bulk"].forEach(name => { const view = $(name + "View"); if (view) view.classList.toggle("active", name === tab); });
    if (tab !== "scan") stopCamera();
    if (tab === "history") renderHistory();
  }
  tabs.forEach(b => b.addEventListener("click", () => { setTab(b.dataset.tab); closeMobileMenu(); }));
  const menuToggle = $("menuToggle");
  function closeMobileMenu() { document.body.classList.remove("menu-open"); menuToggle?.setAttribute("aria-expanded", "false"); menuToggle?.setAttribute("aria-label", "Open tools menu"); }
  menuToggle?.addEventListener("click", () => { const open = !document.body.classList.contains("menu-open"); document.body.classList.toggle("menu-open", open); menuToggle.setAttribute("aria-expanded", String(open)); menuToggle.setAttribute("aria-label", open ? "Close tools menu" : "Open tools menu"); });
  window.addEventListener("resize", () => { if (window.innerWidth > 760) closeMobileMenu(); });

  function setPhotoMode(enabled) {
    $("createView").classList.toggle("photo-mode", enabled);
    if (enabled) state.type = "photo";
    typeButtons.forEach(b => b.classList.toggle("active", enabled ? b.dataset.type === "photo" : b.dataset.type === state.type));
    if (enabled) showMessage("formMessage", "Photo QR selected. Choose an image in the Photo QR settings below.");
  }

  $("photoBackBtn")?.addEventListener("click", () => { setPhotoMode(false); setType("url"); });

  function setType(type) {
    setPhotoMode(false);
    state.type = type;
    if (document.body.classList.contains("generator-mode") && (window.location.pathname.startsWith("/generator"))) syncRoute(type === "url" ? "/generator/url" : "/generator");
    typeButtons.forEach(b => b.classList.toggle("active", b.dataset.type === type));
    $("wifiFields").classList.toggle("hidden", type !== "wifi");
    $("smsFields").classList.toggle("hidden", type !== "sms");
    $("contactFields").classList.toggle("hidden", type !== "contact");
    let html = "";
    const specs = {
      url: ['Link or URL','text','https://example.com or instagram.com/username',''],
      text: ['Text content','text','Type anything you want to share...','Shorter content creates a simpler QR code.'],
      email: ['Email address','email','hello@example.com','Generates an email link that can open a mail app.'],
      phone: ['Phone number','tel','+63 912 345 6789','Includes the number in a tap-to-call link.'],
      wifi: ['Wi-Fi network name (SSID)','text','Network name','Devices can use this to join your Wi-Fi.'],
      sms: ['Phone number','tel','+63 912 345 6789','Generates a prefilled SMS message.'],
      contact: ['Contact details','text','Enter the fields below','Creates a vCard contact QR code.']
    };
    const s = specs[type];
    if (type === "contact") {
      html = `<p class="field-hint">Add a name and at least one contact detail below.</p>`;
    } else {
      html = `<label class="field-label" for="contentInput">${s[0]}</label><input id="contentInput" type="${s[1]}" placeholder="${s[2]}" ${type === "url" || type === "email" ? "required" : ""} ${type === "url" ? 'autocomplete="url"' : ""}><p class="field-hint">${s[3]}</p>`;
    }
    contentFields.innerHTML = html;
    updateDestinationTools();
    if (type === "contact") {
      $("contactFields").classList.remove("hidden");
    } else {
      $("contactFields").classList.add("hidden");
    }
    showMessage("formMessage", "");
  }
  typeButtons.forEach(b => b.addEventListener("click", () => {
    if (b.dataset.type === "photo") setPhotoMode(true);
    else setType(b.dataset.type);
  }));
  $("typeSearch")?.addEventListener("input", () => {
    const query = safeText("typeSearch").toLowerCase();
    typeButtons.forEach(button => { button.hidden = !button.textContent.toLowerCase().includes(query); });
  });
  $("qrForeground")?.addEventListener("input", e => { state.fg = e.target.value; });
  $("qrBackground")?.addEventListener("input", e => { state.bg = e.target.value; });


  // Search and category filters for the visual template library.
  const templateSearch = $("templateSearch");
  const templateCategory = $("templateCategory");
  const templateResultsNote = $("templateResultsNote");
  function filterTemplates() {
    const query = (templateSearch?.value || "").trim().toLowerCase();
    const category = templateCategory?.value || "all";
    let visible = 0;
    document.querySelectorAll("[data-template]").forEach(card => {
      const text = `${card.textContent || ""} ${card.dataset.template || ""}`.toLowerCase();
      const isBusiness = /business|contact|corporate|mono pro|carbon/.test(text);
      const isWifi = /wi-fi|wifi|mint fresh|ice blue|arctic glass/.test(text);
      const isDark = /midnight|neon|carbon|dark/.test(text);
      const isMinimal = /classic|minimal|mono|slate|clean|arctic/.test(text);
      const isColorful = /violet|emerald|rose|ocean|gold|lavender|cobalt|coral|forest|mint|skyline|plum|sunset|berry|lagoon|citrus/.test(text);
      const matchesCategory = category === "all" || (category === "business" && isBusiness) || (category === "wifi" && isWifi) || (category === "dark" && isDark) || (category === "minimal" && isMinimal) || (category === "colorful" && isColorful);
      const show = text.includes(query) && matchesCategory;
      card.hidden = !show;
      if (show) visible++;
    });
    if (templateResultsNote) templateResultsNote.textContent = `${visible} style${visible === 1 ? "" : "s"} available`;
  }
  templateSearch?.addEventListener("input", filterTemplates);
  templateCategory?.addEventListener("change", filterTemplates);

  const QR_TEMPLATES = {
    classic: {type:"url",fg:"#111111",bg:"#ffffff",size:"256",style:"classic"},
    violet: {type:"url",fg:"#087fba",bg:"#ffffff",size:"384",style:"soft"},
    cyan: {type:"url",fg:"#087fba",bg:"#ffffff",size:"384",style:"soft"},
    midnight: {type:"url",fg:"#ffffff",bg:"#171326",size:"384",style:"neon"},
    business: {type:"contact",fg:"#171426",bg:"#ffffff",size:"384",style:"label"},
    wifi: {type:"wifi",fg:"#202020",bg:"#ffffff",size:"256",style:"minimal"},
    event: {type:"text",fg:"#4f2ab8",bg:"#ffffff",size:"384",style:"double"},
    emerald: {type:"url",fg:"#087f5b",bg:"#f0fff8",size:"384",style:"soft"},
    rose: {type:"url",fg:"#b83280",bg:"#fff5fa",size:"384",style:"sticker"},
    ocean: {type:"url",fg:"#075985",bg:"#f0f9ff",size:"384",style:"corner"},
    gold: {type:"url",fg:"#7c4a03",bg:"#fffaf0",size:"384",style:"ticket"},
    lavender: {type:"url",fg:"#6d28d9",bg:"#faf5ff",size:"256",style:"minimal"},
    mono: {type:"contact",fg:"#111827",bg:"#f9fafb",size:"384",style:"classic"},
    businessPro: {type:"contact",fg:"#123047",bg:"#f2f8fb",size:"512",style:"corner"},
    cobalt: {type:"url",fg:"#1d4ed8",bg:"#eff6ff",size:"384",style:"corner"},
    coral: {type:"url",fg:"#9f1239",bg:"#fff1f2",size:"384",style:"sticker"},
    forest: {type:"contact",fg:"#166534",bg:"#f0fdf4",size:"512",style:"classic"},
    slate: {type:"url",fg:"#334155",bg:"#f8fafc",size:"384",style:"minimal"},
    mint: {type:"wifi",fg:"#065f46",bg:"#ecfdf5",size:"384",style:"soft"},
    sky: {type:"url",fg:"#075985",bg:"#f0f9ff",size:"384",style:"soft"},
    plum: {type:"url",fg:"#6b21a8",bg:"#faf5ff",size:"384",style:"double"},
    sunset: {type:"url",fg:"#9a3412",bg:"#fff7ed",size:"384",style:"ticket"},
    berry: {type:"contact",fg:"#9d174d",bg:"#fdf2f8",size:"512",style:"label"},
    ice: {type:"wifi",fg:"#1e40af",bg:"#eff6ff",size:"384",style:"corner"},
    neon: {type:"url",fg:"#087fba",bg:"#e8fbff",size:"512",style:"neon"},
    lagoon: {type:"url",fg:"#087f78",bg:"#eafff8",size:"384",style:"soft"},
    carbon: {type:"contact",fg:"#e4f3f7",bg:"#182733",size:"512",style:"minimal"},
    citrus: {type:"url",fg:"#788900",bg:"#fff9d9",size:"384",style:"sticker"},
    arctic: {type:"wifi",fg:"#197bb6",bg:"#e9f7ff",size:"384",style:"corner"}
  };
  document.querySelectorAll("[data-template]").forEach(button => button.addEventListener("click", () => {
    const t = QR_TEMPLATES[button.dataset.template]; if (!t) return;
    setType(t.type); $("sizeInput").value=t.size; $("styleInput").value=t.style;
    $("qrForeground").value=t.fg; $("qrBackground").value=t.bg; state.fg=t.fg; state.bg=t.bg;
    $("styleInput").dispatchEvent(new Event("change"));
    document.querySelectorAll("[data-template]").forEach(card => card.classList.toggle("selected",card===button));
    showMessage("formMessage", `${button.querySelector("strong")?.textContent || "Template"} applied. Add your content, then generate the QR code.`, "success");
    if (t.type === "wifi") { const input=$("contentInput"); if(input) input.placeholder="Enter your Wi-Fi network name"; }
    showGenerator("create");
  }));

  function getPayload() {
    const value = safeText("contentInput");
    switch (state.type) {
      case "url": {
        if (!value) throw Error("Enter a link first.");
        let raw = value.trim();
        // Add HTTPS for common pasted links without a scheme, while retaining app/deep links.
        if (!/^[a-z][a-z0-9+.-]*:/i.test(raw) && /^(localhost(?::\d+)?|([\w-]+\.)+[a-z]{2,})([/:?#].*)?$/i.test(raw)) raw = "https://" + raw;
        let u; try { u = new URL(raw); } catch { throw Error("Enter a valid link or URL."); }
        if (["javascript:", "data:", "file:", "blob:"].includes(u.protocol.toLowerCase())) throw Error("This link type cannot be encoded for safety.");
        return { text: u.href, title: u.hostname || u.protocol.replace(":", "") || "Link", subtitle: u.href };
      }
      case "text":
        if (!value) throw Error("Enter some text first.");
        return { text: value, title: "Text", subtitle: value };
      case "email":
        if (!value || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) throw Error("Enter a valid email address.");
        return { text: "mailto:" + value, title: "Email", subtitle: value };
      case "phone":
        if (!value) throw Error("Enter a phone number first.");
        return { text: "tel:" + value.replace(/[^\d+*#,;]/g, ""), title: "Phone", subtitle: value };
      case "wifi": {
        if (!value) throw Error("Enter the Wi-Fi network name.");
        const pass = safeText("wifiPassword");
        const hidden = $("wifiHidden").checked ? "true" : "false";
        return { text: `WIFI:T:WPA;S:${escapeWifi(value)};P:${escapeWifi(pass)};H:${hidden};;`, title: "Wi-Fi", subtitle: value };
      }
      case "sms": {
        if (!value) throw Error("Enter a phone number first.");
        const number = value.replace(/[^\d+*#,;]/g, "");
        const message = safeText("smsMessage");
        return { text: `SMSTO:${number}:${message}`, title: "SMS", subtitle: message ? `${number} · ${message}` : number };
      }
      case "contact": {
        const name = safeText("contactName"), phone = safeText("contactPhone"), email = safeText("contactEmail"), org = safeText("contactOrg");
        if (!name) throw Error("Enter the contact's name.");
        if (!phone && !email) throw Error("Add at least a phone number or email.");
        const vcard = ["BEGIN:VCARD","VERSION:3.0",`FN:${name}`, ...(org ? [`ORG:${org}`] : []), ...(phone ? [`TEL;TYPE=CELL:${phone}`] : []), ...(email ? [`EMAIL:${email}`] : []),"END:VCARD"].join("\n");
        return { text: vcard, title: name, subtitle: [phone,email].filter(Boolean).join(" · ") };
      }
    }
  }

  function clearQr() { qrContainer.innerHTML = ""; qrContainer.classList.add("hidden"); qrPlaceholder.classList.remove("hidden"); downloadBtn.disabled = true; downloadSvgBtn.disabled = true; $("printQrBtn").disabled = true; $("printSheetBtn").disabled = true; }
  function waitForImage(src) { return new Promise((resolve, reject) => { const img = new Image(); img.onload = () => resolve(img); img.onerror = reject; img.src = src; }); }
  function getQrSource() {
    const canvas = qrContainer.querySelector("canvas");
    if (canvas) return canvas.toDataURL("image/png");
    const img = qrContainer.querySelector("img");
    return img ? img.src : null;
  }
  function applyQrFrameStyle(style = "classic") {
    const styles = ["soft", "badge", "neon", "minimal", "label", "double", "sticker", "corner", "gradient", "ticket"];
    qrFrame.classList.remove(...styles);
    if (style && style !== "classic") qrFrame.classList.add(style);
    qrFrame.dataset.qrStyle = style || "classic";
    qrFrame.setAttribute("aria-label", `QR code frame style: ${style || "classic"}`);
  }

  async function generate(payload, opts = {}) {
    if (typeof window.QRCode === "undefined") throw Error("QR library did not load. Connect to the internet, reload the preview, and try again.");
    const size = Number(opts.size || $("sizeInput").value || 256);
    const universalMode = false;
    const fg = opts.fg || $("qrForeground")?.value || state.fg || "#000000";
    const bg = opts.bg || $("qrBackground")?.value || state.bg || "#ffffff";
    state.fg = fg; state.bg = bg;
    const qrStyle = opts.style || $("styleInput").value || "classic";
    qrContainer.innerHTML = "";
    applyQrFrameStyle(qrStyle);
    state.qrStyle = qrStyle;
    qrPlaceholder.classList.add("hidden"); qrContainer.classList.remove("hidden");
    // Standard black-on-white QR with high error correction, generated automatically.
    new QRCode(qrContainer, { text: payload.text, width: size, height: size, colorDark: fg, colorLight: bg, correctLevel: QRCode.CorrectLevel.H });
    // qrcodejs renders asynchronously on some browsers; wait for its canvas/image.
    await new Promise(r => setTimeout(r, 80));
    if (!qrContainer.querySelector("canvas") && !qrContainer.querySelector("img")) throw Error("QR could not be rendered. Try shorter content or reload the page.");
    // Show the selected center logo in the live generated preview, not only in exports.
    qrContainer.querySelector(".qr-logo-overlay")?.remove();
    if (state.logoData && state.logoImage) {
      const logo = document.createElement("img");
      logo.className = "qr-logo-overlay";
      logo.src = state.logoData;
      logo.alt = "Center logo";
      logo.setAttribute("aria-label", "Center logo in QR preview");
      qrContainer.appendChild(logo);
    }
    state.qrText = payload.text;
    state.currentName = payload.title;
    $("previewTitle").textContent = payload.title;
    $("previewSubtitle").textContent = payload.subtitle;
    downloadBtn.disabled = false; downloadSvgBtn.disabled = false;
    $("printQrBtn").disabled = false; $("printSheetBtn").disabled = false;
    updateDestinationTools();
    const contrast = qrContrastRatio(fg,bg);
    if (contrast < 4.5) showMessage("formMessage", `QR generated, but the color contrast is low (${contrast.toFixed(1)}:1). Choose darker QR modules or a lighter background, then test before printing.`, "error");
    else showMessage("formMessage", state.logoData ? "QR generated with your selected colors, center logo, and frame. Test it before printing." : "QR generated with your selected colors and frame. Test it before printing.", "success");
    if (!opts.noSave) {
      const item = { id: Date.now().toString(36) + Math.random().toString(36).slice(2,6), type: state.type, title: payload.title, subtitle: payload.subtitle, text: payload.text, fg, bg, size, style: qrStyle, logo: state.logoData || "", universalMode, favorite: false, created: new Date().toISOString() };
      state.history = [item, ...state.history.filter(h => h.text !== item.text)].slice(0, MAX_HISTORY);
      saveHistory(); updateHistoryCounts(); renderHistory();
    }
  }

  function downloadBlob(blob, name) {
    if (!blob || !blob.size) throw Error("The exported file is empty. Generate the QR code again.");
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = name;
    a.style.display = "none";
    document.body.appendChild(a);
    a.click();
    a.remove();
    // Give Android browsers time to begin the download before revoking the URL.
    setTimeout(() => URL.revokeObjectURL(url), 10000);
  }
  async function renderExportCanvas(sizeOverride) {
    const src = getQrSource(); if (!src) throw Error("Generate a QR code first.");
    const qrSize = Number(sizeOverride || $("sizeInput").value || 256);
    const source = await waitForImage(src);
    const style = state.qrStyle || $("styleInput")?.value || "classic";
    const fg = state.fg || $("qrForeground")?.value || "#111111";
    const bg = state.bg || $("qrBackground")?.value || "#ffffff";
    const margin = Math.max(18, Math.round(qrSize * (style === "classic" || style === "minimal" ? .07 : .12)));
    const labelExtra = ["label","sticker","ticket"].includes(style) ? Math.max(34,Math.round(qrSize*.13)) : 0;
    const canvas = document.createElement("canvas");
    canvas.width = qrSize + margin*2; canvas.height = qrSize + margin*2 + labelExtra;
    const ctx = canvas.getContext("2d");
    const roundRect = (x,y,w,h,r) => { ctx.beginPath(); if(ctx.roundRect) ctx.roundRect(x,y,w,h,r); else ctx.rect(x,y,w,h); };
    // Draw the same selected frame concept used by the live .qr-frame preview.
    ctx.fillStyle = bg; ctx.fillRect(0,0,canvas.width,canvas.height);
    if (style === "neon") { ctx.fillStyle = "#171226"; ctx.fillRect(0,0,canvas.width,canvas.height); ctx.strokeStyle="#8b70ff"; ctx.lineWidth=4; ctx.shadowColor="#8b70ff"; ctx.shadowBlur=14; ctx.strokeRect(5,5,canvas.width-10,canvas.height-10); ctx.shadowBlur=0; }
    if (style === "gradient") { const g=ctx.createLinearGradient(0,0,canvas.width,canvas.height); g.addColorStop(0,"#8b70ff"); g.addColorStop(1,"#c1b3ff"); ctx.fillStyle=g; roundRect(0,0,canvas.width,canvas.height,Math.max(18,margin*.7)); ctx.fill(); }
    if (style === "double") { ctx.strokeStyle="#9b87ff"; ctx.lineWidth=4; ctx.strokeRect(4,4,canvas.width-8,canvas.height-8); ctx.lineWidth=1; ctx.strokeRect(11,11,canvas.width-22,canvas.height-22); }
    if (style === "minimal") { ctx.strokeStyle="#d7d9e2"; ctx.lineWidth=1; ctx.strokeRect(1,1,canvas.width-2,canvas.height-2); }
    if (style === "corner") { ctx.strokeStyle="#9b7bff"; ctx.lineWidth=Math.max(3,qrSize*.012); const x=7,y=7,w=canvas.width-14,h=canvas.height-14,L=margin*.42; [[x,y,1,1],[x+w,y,-1,1],[x,y+h,1,-1],[x+w,y+h,-1,-1]].forEach(([a,b,dx,dy])=>{ctx.beginPath();ctx.moveTo(a+dx*L,b);ctx.lineTo(a,b);ctx.lineTo(a,b+dy*L);ctx.stroke();}); }
    if (style === "ticket") { ctx.strokeStyle=fg; ctx.lineWidth=2; ctx.setLineDash([6,4]); ctx.strokeRect(4,4,canvas.width-8,canvas.height-8); ctx.setLineDash([]); }
    if (style === "sticker") { ctx.fillStyle="#f4efff"; roundRect(3,3,canvas.width-6,canvas.height-6,Math.max(14,margin*.65)); ctx.fill(); ctx.strokeStyle="#9b7bff"; ctx.lineWidth=3; ctx.stroke(); }
    if (style === "soft" || style === "badge" || style === "label") { ctx.fillStyle=bg; roundRect(2,2,canvas.width-4,canvas.height-4,style === "badge" ? 24 : 14); ctx.fill(); }
    const qrX=margin, qrY=margin, quiet=Math.max(8,Math.round(qrSize*.04));
    ctx.imageSmoothingEnabled=false; ctx.drawImage(source,qrX,qrY,qrSize,qrSize);
    if (state.logoData) { const logo=state.logoImage||await waitForImage(state.logoData); const side=qrSize*.19,pad=qrSize*.025,lx=qrX+(qrSize-side)/2,ly=qrY+(qrSize-side)/2; ctx.fillStyle=bg; roundRect(lx-pad,ly-pad,side+pad*2,side+pad*2,Math.max(4,qrSize*.025)); ctx.fill(); ctx.drawImage(logo,lx,ly,side,side); }
    if (labelExtra) { ctx.fillStyle=style==="sticker"?"#38245f":fg; ctx.textAlign="center"; ctx.textBaseline="middle"; ctx.font=`800 ${Math.max(11,Math.round(qrSize*.035))}px system-ui`; ctx.fillText(style==="ticket"?"EVENT PASS":style==="sticker"?"MADE TO SCAN":"SCAN ME",canvas.width/2,margin+qrSize+labelExtra/2); }
    return canvas;
  }
  downloadBtn.addEventListener("click", async () => {
    try {
      const canvas = await renderExportCanvas();
      const dataUrl = canvas.toDataURL("image/png");
      const a = document.createElement("a");
      a.href = dataUrl;
      a.download = "quickqr-" + Date.now() + ".png";
      a.style.display = "none";
      document.body.appendChild(a);
      a.click();
      a.remove();
      showMessage("formMessage", "PNG export requested. Check your Downloads folder.", "success");
    } catch (e) { showMessage("formMessage", e.message || "Could not export PNG.", "error"); }
  });
  downloadSvgBtn.addEventListener("click", async () => {
    try {
      // SVG wrapper keeps the QR image crisp at its native pixel size; logo is included when selected.
      const canvas = await renderExportCanvas();
      const png = canvas.toDataURL("image/png");
      const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${canvas.width}" height="${canvas.height}" viewBox="0 0 ${canvas.width} ${canvas.height}"><image width="${canvas.width}" height="${canvas.height}" href="${png}"/></svg>`;
      const blob = new Blob([svg], {type:"image/svg+xml;charset=utf-8"});
      downloadBlob(blob, "quickqr-" + Date.now() + ".svg");
      showMessage("formMessage", "SVG export requested. Check your Downloads folder.", "success");
    } catch (e) { showMessage("formMessage", e.message || "Could not export SVG.", "error"); }
  });

  $("styleInput").addEventListener("change", async () => {
    const style = $("styleInput").value || "classic";
    applyQrFrameStyle(style);
    state.qrStyle = style;
    // Changing a frame updates the visible preview immediately. Keep export/print tied to this exact style.
    if (state.qrText && !qrContainer.classList.contains("hidden")) {
      try {
        await generate({text:state.qrText,title:state.currentName || "QR code",subtitle:$("previewSubtitle")?.textContent || ""},
          {noSave:true,fg:$("qrForeground")?.value || state.fg,bg:$("qrBackground")?.value || state.bg,size:Number($("sizeInput").value||256),style});
      } catch (err) { showMessage("formMessage", err.message || "Could not refresh the QR frame.", "error"); }
    }
  });
  $("logoInput").addEventListener("change", async e => {
    const file = e.target.files?.[0]; if (!file) return;
    if (file.size > 2 * 1024 * 1024) { $("logoStatus").textContent = "Choose a logo under 2 MB."; return; }
    state.logoData = await new Promise((resolve,reject) => { const reader = new FileReader(); reader.onload = () => resolve(reader.result); reader.onerror = reject; reader.readAsDataURL(file); });
    try { state.logoImage = await waitForImage(state.logoData); $("logoStatus").textContent = file.name; if (!qrContainer.classList.contains("hidden") && state.qrText) { qrContainer.querySelector(".qr-logo-overlay")?.remove(); const overlay=document.createElement("img"); overlay.className="qr-logo-overlay"; overlay.src=state.logoData; overlay.alt="Center logo"; qrContainer.appendChild(overlay); } }
    catch { state.logoData = ""; state.logoImage = null; $("logoStatus").textContent = "Could not load that image."; }
  });

  function updateDestinationTools() {
    const result = $("safetyResult"), field = $("contentInput");
    if (!result) return;
    if (state.type !== "url" || !field || !field.value.trim()) {
      result.textContent = state.type === "url" ? "Paste a URL to run a local safety check." : "Safety checks are available for URL QR types.";
      result.className = "safety-result neutral";
      return;
    }
    let raw = field.value.trim();
    if (!/^[a-z][a-z0-9+.-]*:/i.test(raw) && /^(localhost(?::\d+)?|([\w-]+\.)+[a-z]{2,})([/:?#].*)?$/i.test(raw)) raw = "https://" + raw;
    let url;
    try { url = new URL(raw); if (!["http:","https:"].includes(url.protocol.toLowerCase())) throw Error(); }
    catch { result.textContent = "INVALID URL · Enter a complete website URL starting with https:// or http://."; result.className = "safety-result warning"; return; }
    const host=url.hostname.toLowerCase(); const full=url.href.toLowerCase(); const warnings=[]; const notes=[];
    if (url.protocol !== "https:") warnings.push("uses unencrypted HTTP");
    if (url.username || url.password || /@/.test(url.host)) warnings.push("contains embedded credentials or an @-style host pattern");
    if (host.startsWith("xn--") || host.split(".").some(part=>part.startsWith("xn--"))) warnings.push("contains an internationalized/punycode domain that can resemble another brand");
    if (host.split(".").length >= 5) warnings.push("uses an unusually deep subdomain");
    if (/^\d{1,3}(?:\.\d{1,3}){3}$/.test(host)) warnings.push("uses a raw IP address instead of a familiar domain");
    if (/^(localhost|127\.|10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(host)) warnings.push("points to a local/private network address that other users may not be able to reach");
    if (/\.(zip|mov)(?:$)/i.test(host)) notes.push("uses a file-like top-level domain; double-check that the domain is intentional");
    if (/(login|verify|wallet|password|secure|account|gift|claim|prize|reset|signin|banking)/i.test(url.pathname+url.search)) notes.push("path or query contains a keyword sometimes used in phishing messages");
    if (/(bit\.ly|tinyurl\.com|t\.co|goo\.gl|is\.gd|cutt\.ly|rb\.gy)\//i.test(host+url.pathname)) notes.push("appears to use a URL-shortening service, so the final destination is not visible here");
    if (url.port && !["80","443"].includes(url.port)) notes.push("uses a non-standard port");
    if (host.length>60) notes.push("has an unusually long hostname");
    if (warnings.length) { result.textContent = "HIGHER RISK · " + warnings.join("; ") + (notes.length?". Also: "+notes.join("; "):"") + ". Do not trust the link based on this check alone."; result.className = "safety-result warning"; }
    else if (notes.length) { result.textContent = "REVIEW CAREFULLY · " + notes.join("; ") + ". Confirm the exact domain before opening or sharing."; result.className = "safety-result warning"; }
    else { result.textContent = "NO COMMON RED FLAGS DETECTED · " + host + ". This is a local pattern check, not a reputation scan or guarantee of safety."; result.className = "safety-result safe"; }
  }
  document.addEventListener("input", e => { if (e.target?.id === "contentInput") updateDestinationTools(); });
  document.addEventListener("change", e => { if (e.target?.id === "contentInput") updateDestinationTools(); });

  async function makePrintCanvas() { return await renderExportCanvas(Math.max(512, Number($("sizeInput").value || 256))); }
  $("printQrBtn").addEventListener("click", async () => {
    try {
      const canvas = await makePrintCanvas();
      const sheet = $("printSheet"); sheet.innerHTML = `<div class="print-card"><h1>${esc(state.currentName || "QuickQR code")}</h1><p>${esc(state.qrText)}</p><img alt="QR code for printing" src="${canvas.toDataURL("image/png")}"><small>Scan with your phone camera</small></div>`;
      document.body.classList.add("printing-qr"); window.print(); setTimeout(() => document.body.classList.remove("printing-qr"), 800);
    } catch (err) { showMessage("formMessage", err.message || "Could not prepare print layout.", "error"); }
  });
  $("printSheetBtn").addEventListener("click", async () => {
    try {
      const canvas = await makePrintCanvas(); const data = canvas.toDataURL("image/png"); const sheet = $("printSheet");
      sheet.innerHTML = `<h1 class="print-sheet-title">QuickQR Plus · Print Sheet</h1><div class="print-grid">${Array.from({length:6}, (_,i) => `<div class="print-card"><h2>${esc(state.currentName || "QR code")}</h2><img alt="QR code copy ${i+1}" src="${data}"><p>${esc(state.qrText)}</p></div>`).join("")}</div><p class="print-footer">Print at 100% scale. Keep the white margin around each QR code clear.</p>`;
      document.body.classList.add("printing-sheet"); window.print(); setTimeout(() => document.body.classList.remove("printing-sheet"), 800);
    } catch (err) { showMessage("formMessage", err.message || "Could not prepare print sheet.", "error"); }
  });

  qrForm.addEventListener("submit", async e => {
    e.preventDefault();
    try {
      const payload = getPayload();
      await generate(payload);
    }
    catch (err) { clearQr(); showMessage("formMessage", err.message || "Could not generate the QR code.", "error"); }
  });

  function updateHistoryCounts() { $("historyCount").textContent = state.history.length; $("tabHistoryCount").textContent = state.history.length; }
  function renderHistory() {
    const list = $("historyList"); const query = (safeText("historySearch") || "").toLowerCase();
    const items = state.history.filter(h => `${h.title} ${h.subtitle} ${h.text}`.toLowerCase().includes(query));
    updateHistoryCounts();
    if (!items.length) {
      list.innerHTML = `<div class="history-empty"><span class="history-empty-icon" data-icon="history" aria-hidden="true"></span><div><strong>${query ? "No matching QR codes" : "No QR codes yet"}</strong><p>${query ? "Try another search." : "Generated codes will be saved on this device."}</p></div></div>`;
      hydrateIcons();
      return;
    }
    list.innerHTML = items.map(h => `<article class="history-item ${h.favorite ? "is-favorite" : ""}" data-id="${esc(h.id)}"><div class="history-thumb"><span data-icon="qr-code" aria-hidden="true"></span></div><div class="history-meta"><strong>${h.favorite ? '<span class="favorite-marker" data-icon="check-circle" aria-label="Favorite"></span>' : ""}${esc(h.title)}</strong><span>${esc(h.type.toUpperCase())} · ${esc(h.subtitle).slice(0,110)}</span></div><div class="history-actions"><button class="mini-button" data-action="favorite" data-id="${esc(h.id)}" aria-pressed="${!!h.favorite}">${h.favorite ? '<span data-icon="check-circle" aria-hidden="true"></span> Saved' : '<span data-icon="plus" aria-hidden="true"></span> Favorite'}</button><button class="mini-button" data-action="reuse" data-id="${esc(h.id)}">Reuse</button><button class="mini-button" data-action="rename" data-id="${esc(h.id)}">Rename</button><button class="mini-button danger" data-action="delete" data-id="${esc(h.id)}">Delete</button></div></article>`).join("");
    hydrateIcons();
    // Render lightweight thumbnail QR codes in the history cards.
    items.forEach(h => { const article = list.querySelector(`[data-id="${CSS.escape(h.id)}"]`); const thumb = article?.querySelector(".history-thumb"); if (thumb && window.QRCode) { thumb.innerHTML = ""; try { new QRCode(thumb,{text:h.text,width:44,height:44,colorDark:h.fg || "#000000",colorLight:h.bg || "#ffffff",correctLevel:QRCode.CorrectLevel.H}); } catch {} } });
  }
  $("historySearch").addEventListener("input", renderHistory);
  $("historyList").addEventListener("click", async e => {
    const b = e.target.closest("button[data-action]"); if (!b) return;
    const item = state.history.find(h => h.id === b.dataset.id); if (!item) return;
    if (b.dataset.action === "delete") {
      state.history = state.history.filter(h => h.id !== item.id); saveHistory(); renderHistory(); return;
    }
    if (b.dataset.action === "favorite") {
      item.favorite = !item.favorite; saveHistory(); renderHistory(); return;
    }
    if (b.dataset.action === "rename") {
      const name = prompt("Rename this QR code:", item.title);
      if (name && name.trim()) { item.title = name.trim(); saveHistory(); renderHistory(); }
      return;
    }
    if (b.dataset.action === "reuse") {
      setTab("create"); setType(item.type);
      if (item.type === "wifi") {
        const m = item.text.match(/^WIFI:T:[^;]*;S:((?:\\.|[^;])*)/); if (m) { const ssid = m[1].replace(/\\([\\;,:"'])/g,"$1"); $("contentInput").value = ssid; }
        const p = item.text.match(/;P:((?:\\.|[^;])*)/); if (p) $("wifiPassword").value = p[1].replace(/\\([\\;,:"'])/g,"$1");
      } else if (item.type === "contact") {
        const field = (k) => (item.text.match(new RegExp("^" + k + ":(.*)$","m")) || [,""])[1];
        $("contactName").value = field("FN"); $("contactPhone").value = field("TEL;TYPE=CELL"); $("contactEmail").value = field("EMAIL"); $("contactOrg").value = field("ORG");
      } else if (item.type === "sms") {
        const m = item.text.match(/^SMSTO:([^:]*):(.*)$/s); $("contentInput").value = m ? m[1] : ""; $("smsMessage").value = m ? m[2] : "";
      } else if (item.type === "email") $("contentInput").value = item.text.replace(/^mailto:/,"");
      else if (item.type === "phone") $("contentInput").value = item.text.replace(/^tel:/,"");
      else $("contentInput").value = item.text;
      $("sizeInput").value = String(item.size || 256); $("styleInput").value = item.style || "classic";
      $("qrForeground").value = item.fg || "#000000"; $("qrBackground").value = item.bg || "#ffffff"; state.fg = $("qrForeground").value; state.bg = $("qrBackground").value;
      state.logoData = item.logo || ""; state.logoImage = null;
      if (state.logoData) { try { state.logoImage = await waitForImage(state.logoData); $("logoStatus").textContent = "Saved logo loaded"; } catch { state.logoData = ""; $("logoStatus").textContent = "No logo selected"; } }
      try { await generate({text:item.text,title:item.title,subtitle:item.subtitle},{noSave:true,fg:item.fg,bg:item.bg,size:item.size,style:item.style}); showMessage("formMessage","Loaded saved QR code.","success"); } catch(err) { showMessage("formMessage",err.message,"error"); }
    }
  });
  $("clearHistoryBtn").addEventListener("click", () => { if (!state.history.length) return; if (confirm("Delete all saved QR history from this browser?")) { state.history = []; saveHistory(); renderHistory(); } });


  document.querySelectorAll("[data-quick-type]").forEach(button => button.addEventListener("click", () => { showGenerator("create"); setType(button.dataset.quickType); }));
  document.querySelectorAll("[data-design-preset]").forEach(button => button.addEventListener("click", () => {
    const presets = { classic: {fg:"#000000",bg:"#ffffff",style:"classic"}, cyan: {fg:"#087fba",bg:"#ffffff",style:"soft"}, violet: {fg:"#087fba",bg:"#ffffff",style:"soft"}, midnight: {fg:"#ffffff",bg:"#171326",style:"minimal"} };
    const preset = presets[button.dataset.designPreset]; if (!preset) return;
    showGenerator("create");
    $("qrForeground").value = preset.fg; $("qrBackground").value = preset.bg; $("styleInput").value = preset.style;
    state.fg = preset.fg; state.bg = preset.bg; $("styleInput").dispatchEvent(new Event("change"));
    showMessage("formMessage", "Design preset selected. Add your content and generate the QR code.", "success");
  }));

  // Bulk QR generation and ZIP export run entirely in the browser.
  function parseBulkRows(raw) {
    return raw.split(/\r?\n/).map(line => line.trim()).filter(Boolean).map((line, index) => {
      const split = line.indexOf("|");
      let name, content;
      if (split >= 0) { name = line.slice(0, split).trim(); content = line.slice(split + 1).trim(); }
      else { content = line.trim(); name = "QR-" + String(index + 1).padStart(3, "0"); }
      if (!content) return null;
      return {name: (name || "QR-" + (index + 1)).replace(/[\\/:*?"<>|]/g, "-").slice(0,80), content};
    }).filter(Boolean);
  }
  $("bulkPreviewBtn").addEventListener("click", () => {
    const rows = parseBulkRows($("bulkInput").value);
    $("bulkSummary").classList.remove("hidden");
    $("bulkSummary").textContent = rows.length ? `${rows.length} QR item(s) ready. Maximum per ZIP: ${BULK_LIMIT}.` : "Add at least one line using Name | URL or text.";
    showMessage("bulkMessage", rows.length > BULK_LIMIT ? "Please split this list into batches of 100 or fewer." : "Bulk list checked.", rows.length > BULK_LIMIT ? "error" : "success");
  });
  $("bulkCsvInput").addEventListener("change", async e => {
    const file = e.target.files?.[0]; if (!file) return;
    if (file.size > 2 * 1024 * 1024) { showMessage("bulkMessage", "CSV must be smaller than 2 MB.", "error"); e.target.value=""; return; }
    try { $("bulkInput").value = (await file.text()).split(/\r?\n/).map((line,i) => {
      if (!line.trim()) return "";
      const cells = line.split(",").map(x => x.trim().replace(/^\"|\"$/g,""));
      if (i===0 && /name|title/i.test(cells[0]) && /url|content|text/i.test(cells[1]||"")) return "";
      return cells.length > 1 ? `${cells[0]} | ${cells.slice(1).join(",")}` : cells[0];
    }).filter(Boolean).join("\n");
    showMessage("bulkMessage", "CSV loaded. Preview the count before generating.", "success");
    } catch { showMessage("bulkMessage", "Could not read that CSV file.", "error"); }
    e.target.value="";
  });
  $("bulkGenerateBtn").addEventListener("click", async () => {
    const rows = parseBulkRows($("bulkInput").value);
    if (!rows.length) { showMessage("bulkMessage", "Add at least one item first.", "error"); return; }
    if (rows.length > BULK_LIMIT) { showMessage("bulkMessage", `Maximum ${BULK_LIMIT} items per ZIP. Split the list into smaller batches.`, "error"); return; }
    if (!window.QRCode) { showMessage("bulkMessage", "QR library did not load. Connect to the internet and reload.", "error"); return; }
    if (!window.JSZip) { showMessage("bulkMessage", "ZIP library did not load. Connect to the internet and reload.", "error"); return; }
    const button = $("bulkGenerateBtn"); button.disabled = true; button.textContent = "Generating…";
    const stage = $("bulkStage"); stage.innerHTML="";
    try {
      const zip = new JSZip();
      for (let i=0;i<rows.length;i++) {
        const row=rows[i]; const holder=document.createElement("div"); stage.appendChild(holder);
        new QRCode(holder,{text:row.content,width:512,height:512,colorDark:"#000000",colorLight:"#ffffff",correctLevel:QRCode.CorrectLevel.H});
        await new Promise(resolve=>setTimeout(resolve,60));
        const canvas=holder.querySelector("canvas");
        if (!canvas) throw Error(`Could not generate QR for row ${i+1}. Try shorter content.`);
        const blob=await new Promise(resolve=>canvas.toBlob(resolve,"image/png"));
        if (!blob) throw Error(`Could not export QR for ${row.name}.`);
        zip.file(`${String(i+1).padStart(3,"0")}-${row.name}.png`,blob);
        holder.remove();
      }
      zip.file("README.txt", `QuickQR Plus bulk export\nCreated: ${new Date().toLocaleString()}\nQR codes: ${rows.length}\n\nEach PNG file contains a static QR code for the content supplied in the bulk list.\n`);
      const blob=await zip.generateAsync({type:"blob"});
      downloadBlob(blob,`quickqr-bulk-${new Date().toISOString().slice(0,10)}.zip`);
      $("bulkSummary").classList.remove("hidden"); $("bulkSummary").textContent=`Successfully prepared ${rows.length} QR code(s) in a ZIP archive.`;
      showMessage("bulkMessage","ZIP export started. Check your Downloads folder.","success");
    } catch(err) { showMessage("bulkMessage",err.message || "Bulk export failed.","error"); }
    finally { stage.innerHTML=""; button.disabled=false; button.textContent="Generate ZIP"; }
  });

  // Photo-to-QR uploads the selected image to a public Supabase Storage bucket.
  function supabaseClient() {
    const cfg = window.QUICKQR_SUPABASE || {};
    if (!cfg.url || !cfg.anonKey || /YOUR_|PASTE_/i.test(cfg.url + cfg.anonKey)) {
      throw new Error("Add your Supabase Project URL and anon key in supabase-config.js first.");
    }
    if (!window.supabase?.createClient) throw new Error("Supabase library did not load. Reload while online.");
    if (!window.__quickqrSupabaseClient) window.__quickqrSupabaseClient = window.supabase.createClient(cfg.url, cfg.anonKey);
    return window.__quickqrSupabaseClient;
  }
  function compressPhoto(file) {
    return new Promise((resolve, reject) => {
      const tempUrl = URL.createObjectURL(file);
      const image = new Image();
      image.onload = () => {
        try {
          const maxSide = 1600, scale = Math.min(1, maxSide / Math.max(image.naturalWidth, image.naturalHeight));
          const c = document.createElement("canvas");
          c.width = Math.max(1, Math.round(image.naturalWidth * scale));
          c.height = Math.max(1, Math.round(image.naturalHeight * scale));
          c.getContext("2d", {alpha:false}).drawImage(image, 0, 0, c.width, c.height);
          URL.revokeObjectURL(tempUrl);
          c.toBlob(blob => blob ? resolve({ blob, preview: c.toDataURL("image/jpeg", 0.82), width:c.width, height:c.height }) : reject(new Error("Could not prepare this image.")), "image/jpeg", 0.82);
        } catch (err) { URL.revokeObjectURL(tempUrl); reject(err); }
      };
      image.onerror = () => { URL.revokeObjectURL(tempUrl); reject(new Error("Could not open this image. Try a different photo.")); };
      image.src = tempUrl;
    });
  }
  $("photoFileInput").addEventListener("change", async e => {
    const file = e.target.files?.[0]; if (!file) return;
    if (!file.type.startsWith("image/")) { showMessage("photoMessage", "Choose an image file.", "error"); return; }
    if (file.size > 10 * 1024 * 1024) { showMessage("photoMessage", "Choose an image smaller than 10 MB.", "error"); e.target.value = ""; return; }
    showMessage("photoMessage", "Preparing photo…");
    try {
      const result = await compressPhoto(file);
      selectedPhotoData = result.preview;
      selectedPhotoFile = result.blob;
      $("photoPreview").src = result.preview;
      $("photoPreviewWrap").classList.remove("hidden");
      $("photoFileName").textContent = file.name || "Selected photo";
      $("photoDimensions").textContent = `${result.width} × ${result.height} px`;
      if (!$("photoNameInput").value.trim()) $("photoNameInput").value = (file.name || "My photo").replace(/\.[^.]+$/, "").slice(0,60);
      $("generatePhotoQrBtn").disabled = false;
      currentPhotoPublicUrl = "";
      showMessage("photoMessage", "Photo ready to upload.", "success");
    } catch (err) { selectedPhotoData = ""; selectedPhotoFile = null; $("generatePhotoQrBtn").disabled = true; showMessage("photoMessage", err.message || "Could not prepare this image.", "error"); }
    e.target.value = "";
  });

  $("generatePhotoQrBtn").addEventListener("click", async () => {
    if (!selectedPhotoFile) { showMessage("photoMessage", "Choose a photo first.", "error"); return; }
    const btn = $("generatePhotoQrBtn"); btn.disabled = true; btn.textContent = "Uploading photo…";
    try {
      const client = supabaseClient();
      const cfg = window.QUICKQR_SUPABASE;
      const title = safeText("photoNameInput") || "QuickQR photo";
      const ext = "jpg";
      const path = `${new Date().getUTCFullYear()}/${crypto.randomUUID ? crypto.randomUUID() : Date.now()+"-"+Math.random().toString(36).slice(2)}.${ext}`;
      const { error: uploadError } = await client.storage.from(cfg.bucket || "quickqr-photos").upload(path, selectedPhotoFile, { contentType:"image/jpeg", cacheControl:"31536000", upsert:false });
      if (uploadError) throw uploadError;
      const { data } = client.storage.from(cfg.bucket || "quickqr-photos").getPublicUrl(path);
      currentPhotoPublicUrl = data?.publicUrl;
      if (!currentPhotoPublicUrl) throw new Error("Could not create a public photo link. Check the bucket settings.");
      if (typeof window.QRCode === "undefined") throw new Error("QR library did not load. Reload while online.");
      const out = $("photoQrOutput"); out.innerHTML = "";
      new QRCode(out, { text: currentPhotoPublicUrl, width:280, height:280, colorDark:"#000000", colorLight:"#ffffff", correctLevel:QRCode.CorrectLevel.H });
      await new Promise(r => setTimeout(r, 100));
      if (!out.querySelector("canvas") && !out.querySelector("img")) throw new Error("Could not generate the QR code.");
      if (state.logoData && state.logoImage) { const logo=document.createElement("img"); logo.className="qr-logo-overlay"; logo.src=state.logoData; logo.alt="Center logo"; out.appendChild(logo); }
      out.classList.remove("hidden"); $("photoQrPlaceholder").classList.add("hidden");
      $("downloadPhotoQrBtn").disabled = false; $("viewLocalPhotoBtn").disabled = false;
      showMessage("photoMessage", "Photo uploaded. Scan the QR to open the image on any device.", "success");
    } catch (err) {
      console.error("Photo upload failed:", err);
      showMessage("photoMessage", err.message || "Upload failed. Check Supabase setup and storage policies.", "error");
    } finally { btn.disabled = !selectedPhotoFile; btn.innerHTML = 'Upload &amp; Generate Photo QR <span aria-hidden="true" data-icon="arrow-up-right"></span>'; hydrateIcons(); }
  });
  $("downloadPhotoQrBtn").addEventListener("click", async () => {
    try {
      const out = $("photoQrOutput"), source = out.querySelector("canvas") || out.querySelector("img");
      if (!source) throw new Error("Generate the photo QR first.");
      const size=560, canvas=document.createElement("canvas"); canvas.width=size; canvas.height=size;
      const ctx=canvas.getContext("2d"); ctx.fillStyle="#fff"; ctx.fillRect(0,0,size,size);
      const image=await waitForImage(source.toDataURL ? source.toDataURL("image/png") : source.src);
      const quiet=28; ctx.imageSmoothingEnabled=false; ctx.drawImage(image,quiet,quiet,size-quiet*2,size-quiet*2);
      if (state.logoData) { const logo=state.logoImage || await waitForImage(state.logoData); const side=size*.19,x=(size-side)/2,y=(size-side)/2,pad=size*.025; ctx.fillStyle="#fff"; ctx.fillRect(x-pad,y-pad,side+pad*2,side+pad*2); ctx.drawImage(logo,x,y,side,side); }
      const blob=await (await fetch(canvas.toDataURL("image/png"))).blob(); downloadBlob(blob, `quickqr-photo-${Date.now()}.png`);
    } catch (err) { showMessage("photoMessage", err.message || "Could not download QR image.", "error"); }
  });
  $("viewLocalPhotoBtn").addEventListener("click", () => {
    if (!currentPhotoPublicUrl) { showMessage("photoMessage", "Generate the photo QR first.", "error"); return; }
    window.open(currentPhotoPublicUrl, "_blank", "noopener,noreferrer");
  });

  // QR Scanner: camera loop plus uploaded-image decoding via jsQR.
  const video = $("scannerVideo"), canvas = $("scannerCanvas"), ctx = canvas.getContext("2d", {willReadFrequently:true});
  function showScanResult(text) {
    $("scanText").textContent = text; $("scanResult").classList.remove("hidden");
    const link = $("openScanLink");
    try { const u = new URL(text); if (!["javascript:","data:","file:","blob:"].includes(u.protocol.toLowerCase())) { link.href = u.href; link.classList.remove("hidden"); } else link.classList.add("hidden"); } catch { link.classList.add("hidden"); }
    const oldPhoto = $("scanLocalPhoto"); if (oldPhoto) oldPhoto.remove();
    showMessage("scanMessage","QR code detected. Verify the destination before opening unfamiliar links.","success");
    stopCamera();
  }
  $("openScanLink")?.addEventListener("click", event => {
    const link = $("openScanLink");
    try { const u = new URL(link.href); if (!confirm(`Open this link?\n\n${u.hostname}\n\nOnly continue if you trust this destination.`)) event.preventDefault(); }
    catch { event.preventDefault(); }
  });
  function stopCamera() {
    if (state.scanTimer) { cancelAnimationFrame(state.scanTimer); state.scanTimer = null; }
    if (state.stream) { state.stream.getTracks().forEach(t => t.stop()); state.stream = null; }
    video.srcObject = null; video.classList.add("hidden"); if ($("scanImagePreview")?.classList.contains("hidden")) $("scannerPlaceholder").classList.remove("hidden"); $("stopCameraBtn").disabled = true; $("startCameraBtn").disabled = false;
  }
  async function startCamera() {
    if (!navigator.mediaDevices?.getUserMedia) { showMessage("scanMessage","Camera is unavailable in this preview. Use image upload or try HTTPS/localhost.","error"); return; }
    if (!window.jsQR) { showMessage("scanMessage","Scanner library did not load. Connect to the internet and reload the preview.","error"); return; }
    try {
      state.stream = await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:"environment"}},audio:false});
      video.srcObject = state.stream; video.classList.remove("hidden"); $("scannerPlaceholder").classList.add("hidden"); $("scanImagePreview")?.classList.add("hidden"); $("startCameraBtn").disabled = true; $("stopCameraBtn").disabled = false;
      await video.play();
      const tick = () => {
        if (!state.stream) return;
        if (video.readyState === video.HAVE_ENOUGH_DATA) {
          canvas.width = video.videoWidth; canvas.height = video.videoHeight; ctx.drawImage(video,0,0,canvas.width,canvas.height);
          const image = ctx.getImageData(0,0,canvas.width,canvas.height);
          const code = window.jsQR(image.data,image.width,image.height,{inversionAttempts:"attemptBoth"});
          if (code?.data) { showScanResult(code.data); return; }
        }
        state.scanTimer = requestAnimationFrame(tick);
      };
      tick(); showMessage("scanMessage","Point your camera at a QR code.");
    } catch (err) { stopCamera(); showMessage("scanMessage","Camera permission denied or unavailable. Try uploading a QR image instead.","error"); }
  }
  $("startCameraBtn").addEventListener("click", startCamera);
  $("stopCameraBtn").addEventListener("click", () => { stopCamera(); showMessage("scanMessage","Camera stopped."); });
  $("scanFileInput").addEventListener("change", async e => {
    const file = e.target.files?.[0]; if (!file) return;
    if (!file.type.startsWith("image/")) { showMessage("scanMessage", "Choose an image file.", "error"); e.target.value = ""; return; }
    const scanImageObjectUrl = URL.createObjectURL(file);
    const previewWrap = $("scanImagePreview");
    const previewImg = $("scanUploadedImage");
    previewImg.src = scanImageObjectUrl;
    previewWrap.classList.remove("hidden");
    $("scannerPlaceholder").classList.add("hidden");
    try {
      if (!window.jsQR) throw new Error("Scanner library did not load. Connect to the internet and reload.");
      const img = await waitForImage(scanImageObjectUrl);
      canvas.width = img.naturalWidth; canvas.height = img.naturalHeight; ctx.drawImage(img,0,0);
      const data = ctx.getImageData(0,0,canvas.width,canvas.height);
      const code = window.jsQR(data.data,data.width,data.height,{inversionAttempts:"attemptBoth"});
      if (code?.data) showScanResult(code.data); else showMessage("scanMessage","Image preview loaded, but no QR code was found. Try a clearer image.","error");
    } catch (err) { showMessage("scanMessage", err.message || "Could not read that image. Try another file.","error"); }
    finally { e.target.value = ""; }
  });
  $("copyScanBtn").addEventListener("click", async () => {
    const text = $("scanText").textContent;
    try { await navigator.clipboard.writeText(text); showMessage("scanMessage","Copied to clipboard.","success"); }
    catch { const ta = document.createElement("textarea"); ta.value = text; document.body.appendChild(ta); ta.select(); document.execCommand("copy"); ta.remove(); showMessage("scanMessage","Copied to clipboard.","success"); }
  });

  // Help Center replies are concise, topic-specific, and do not require an external AI API.
  // Bug reports are stored in this browser and can be sent to the developer by email.
  const supportChat = $("supportChat"), supportBody = $("supportChatBody"), supportInput = $("supportChatInput");
  function addSupportMessage(text, who="bot") { if (!supportBody) return; const bubble=document.createElement("div"); bubble.className="chat-message "+(who==="user"?"user-message":"bot-message"); bubble.textContent=text; supportBody.appendChild(bubble); supportBody.scrollTop=supportBody.scrollHeight; }
  function saveBugReport(message) {
    const reports=(()=>{try{return JSON.parse(localStorage.getItem("quickqr-plus-bug-reports")||"[]")}catch{return []}})();
    reports.unshift({message,createdAt:new Date().toISOString(),page:location.href,userAgent:navigator.userAgent});
    try { localStorage.setItem("quickqr-plus-bug-reports",JSON.stringify(reports.slice(0,30))); addSupportMessage("Bug report saved in this browser. Include what you clicked, what you expected, and what happened. You can copy the report below to send it to the developer."); }
    catch { addSupportMessage("I couldn't save this report because browser storage is unavailable. Copy the details and keep them somewhere safe."); }
    const reportText="QuickQR Plus bug report\nDate: "+new Date().toLocaleString()+"\nPage: "+location.href+"\nIssue: "+message+"\nDevice: "+navigator.userAgent;
    const copy=document.createElement("button"); copy.type="button"; copy.className="support-copy-report"; copy.textContent="Copy bug report"; copy.addEventListener("click",async()=>{try{await navigator.clipboard.writeText(reportText);copy.textContent="Copied report"}catch{addSupportMessage(reportText)}}); supportBody.appendChild(copy); supportBody.scrollTop=supportBody.scrollHeight;
  }
  function localSupportReply(message) {
    const q=message.toLowerCase().trim().replace(/[?!.,]+$/g, "").replace(/\s+/g, " ");
    // A simple "QR scanner" prompt returns only the overview, not troubleshooting steps.
    if (/^(what is )?(the )?(qr )?scanner( tool)?$/.test(q) || /^(about|tell me about) (the )?(qr )?scanner$/.test(q) || /^(qr scanner|scanner|about qr scanner)$/.test(q)) return "About QR Scanner: The QR Scanner reads a QR code using your device camera or an uploaded image, then displays the information encoded in it. If the result is a website link, you can review it before opening it. Camera scanning needs permission and works best on a secure HTTPS website.";
    if (/(scanner issue|scanner not working|camera issue|camera not working|can't scan|cannot scan|scan failed|troubleshoot scanner|qr scanner help|help with scanner)/.test(q)) return "QR Scanner troubleshooting: Allow camera permission and use the website over HTTPS. If the camera does not start, stop and restart scanning, close other apps using the camera, or upload a clear QR image. Keep the code in focus and fully visible.";
    if (/(generate|generator|create|download|png|svg|not working|doesn't work|blank)/.test(q)) return "QR generation help: choose a QR type, enter valid content, and select Generate. If no code appears, check the input and try again after the page finishes loading. For downloads, try PNG first. For Wi-Fi QR codes, verify the network name, password, and security type.";
    if (/(photo|supabase|share|image)/.test(q)) return "Photo-to-QR help: check that supabase-config.js has the correct project URL and anon/publishable key, then run supabase-setup.sql. The uploaded image needs a public URL for other devices to open it. Never put a Supabase service_role key in frontend code.";
    if (/(template|business|design|color|style|frame)/.test(q)) return "Template Library help: choose a preset in the generator to apply its QR type, colors, size, and frame. Enter your own content, generate the QR, and test-scan it before printing. Business Pro and Business Card are designed for contact details.";
    if (/(history|saved|reuse|delete)/.test(q)) return "History help: your saved QR entries are stored in this browser. Use Reuse to restore settings, and use the available actions to rename, favorite, export, or delete entries. Clearing browser/site data may erase local history.";
    if (/(offline|internet|connection)/.test(q)) return "Connection help: local QR generation and history can work after the page has loaded and cached. External libraries and Photo-to-QR uploads may need an internet connection.";
    if (/(help|faq|center|how|support)/.test(q)) return "I can help with QR generation, design templates, PNG/SVG downloads, scanning, Photo-to-QR, browser history, and bug reports. Tell me which feature you need help with.";
    return "I can help with QR generation, QR scanner, templates, downloads, Photo-to-QR, and history. Try a topic such as “QR scanner”, “templates”, or “download QR”. For a bug, describe what you clicked and what happened, or use Message developer.";
  }
  function supportReply(message) {
    const q=message.toLowerCase();
    if (/(bug report|report a bug|submit a bug|send a bug report|\bbug\b|\berror\b|\bbroken\b)/.test(q)) { saveBugReport(message); return; }
    addSupportMessage(localSupportReply(message));
  }
  function toggleSupport(open) { if (!supportChat) return; supportChat.hidden=!open; $("supportLauncher")?.setAttribute("aria-expanded",String(open)); if(open) setTimeout(()=>supportInput?.focus(),50); }
  $("supportLauncher")?.addEventListener("click",()=>toggleSupport(supportChat?.hidden)); $("supportCloseBtn")?.addEventListener("click",()=>toggleSupport(false));
  $("supportChatForm")?.addEventListener("submit",e=>{e.preventDefault();const value=(supportInput?.value||"").trim();if(!value)return;addSupportMessage(value,"user");supportInput.value="";void supportReply(value)});
  document.querySelectorAll("[data-support-topic]").forEach(button=>button.addEventListener("click",()=>{const topic=button.dataset.supportTopic;const prompts={help:"Help center",bug:"I want to report a bug",qr:"QR code is not generating",scan:"Scanner camera issue"};addSupportMessage(prompts[topic],"user");void supportReply(prompts[topic])}));

  function updateConnectionStatus() {
    const online = navigator.onLine;
    $("offlineNotice").classList.toggle("offline", !online);
    const modeLabel = $("connectionModeLabel");
    if (modeLabel) modeLabel.textContent = online ? "ONLINE MODE" : "OFFLINE MODE";
    $("connectionText").textContent = online ? "Internet connection detected. Some features still depend on external services." : "No internet connection detected. Local tools work; uploads and external services need internet.";
  }
  window.addEventListener("online", updateConnectionStatus); window.addEventListener("offline", updateConnectionStatus); updateConnectionStatus();

  if ("serviceWorker" in navigator && location.protocol !== "file:") {
    window.addEventListener("load", () => navigator.serviceWorker.register("./sw.js").catch(err => console.warn("Service worker unavailable in this preview:", err)));
  }


  // Accessible light/dark theme toggle; preference is saved locally.
  const themeToggle = $("themeToggle");
  function applyTheme(theme) {
    document.documentElement.dataset.theme = theme;
    const isDark = theme !== "light";
    if (themeToggle) {
      themeToggle.setAttribute("aria-label", isDark ? "Switch to light mode" : "Switch to dark mode");
      themeToggle.setAttribute("title", isDark ? "Switch to light mode" : "Switch to dark mode");
      const label = themeToggle.querySelector(".theme-toggle-label"); if (label) label.textContent = isDark ? "Light mode" : "Dark mode";
      const icon = themeToggle.querySelector("[data-icon]"); if (icon) icon.dataset.icon = isDark ? "sun" : "moon";
      if (typeof hydrateIcons === "function") hydrateIcons();
    }
    try { localStorage.setItem("quickqr-theme", theme); } catch (_) {}
  }
  let savedTheme = "light"; try { savedTheme = localStorage.getItem("quickqr-theme") || "light"; } catch (_) {}
  applyTheme(savedTheme);
  if (themeToggle) themeToggle.addEventListener("click", () => applyTheme(document.documentElement.dataset.theme === "light" ? "dark" : "light"));

  state.history = readHistory(); updateHistoryCounts(); renderHistory(); setType("url"); filterTemplates(); loadRoute();

  // Guided three-stage QR creation flow inspired by the reference generator.
  const workflowRoot = document.querySelector('#createView');
  let workflowStage = 'content';
  const workflowSelectors = {
    content: ['.type-picker-heading', '#typeGrid', '#contentFields', '.content-step-actions'],
    design: ['.template-library', '.destination-tools', '.settings-divider', '.settings-row', '.qr-default-note', '#styleInput', '.color-controls', '.compatibility-card', '.logo-control', '.extra-fields', '.design-step-actions']
  };
  function setWorkflowStage(stage) {
    if (!workflowRoot || !['content','design','download'].includes(stage)) return;
    workflowStage = stage;
    workflowRoot.querySelectorAll('.workflow-hidden').forEach(el => el.classList.remove('workflow-hidden'));
    if (stage === 'content') {
      workflowSelectors.design.forEach(sel => workflowRoot.querySelectorAll(sel).forEach(el => el.classList.add('workflow-hidden')));
      workflowRoot.querySelector('.preview-panel')?.classList.add('workflow-hidden');
    } else if (stage === 'design') {
      workflowSelectors.content.filter(sel => !sel.includes('content-step-actions')).forEach(sel => workflowRoot.querySelectorAll(sel).forEach(el => el.classList.add('workflow-hidden')));
      workflowRoot.querySelector('.content-step-actions')?.classList.add('workflow-hidden');
      workflowRoot.querySelector('.preview-panel')?.classList.add('workflow-hidden');
    } else {
      workflowRoot.querySelector('.editor-panel')?.classList.add('workflow-hidden');
      workflowRoot.querySelector('.preview-panel')?.classList.remove('workflow-hidden');
    }
    workflowRoot.querySelectorAll('[data-workflow-step]').forEach(btn => {
      const current = btn.dataset.workflowStep === stage;
      btn.classList.toggle('is-current', current);
      btn.classList.toggle('is-complete', ['content','design','download'].indexOf(btn.dataset.workflowStep) < ['content','design','download'].indexOf(stage));
      btn.setAttribute('aria-current', current ? 'step' : 'false');
    });
    const top = workflowRoot.querySelector('.qr-workflow');
    if (top) top.dataset.currentStep = stage;
  }
  document.querySelector('#contentNextBtn')?.addEventListener('click', () => {
    const type = document.querySelector('.type-button.active')?.dataset.type || 'url';
    const input = document.querySelector('#contentInput');
    if (type === 'url' && input && !input.value.trim()) { input.reportValidity(); input.focus(); return; }
    if (type !== 'url' && input && !input.value.trim() && !['wifi','contact'].includes(type)) { input.reportValidity(); input.focus(); return; }
    setWorkflowStage('design');
    workflowRoot?.scrollIntoView({behavior:'smooth',block:'start'});
  });
  document.querySelector('#designBackBtn')?.addEventListener('click', () => setWorkflowStage('content'));
  document.querySelector('#downloadBackBtn')?.addEventListener('click', () => setWorkflowStage('design'));
  document.querySelector('#startAnotherBtn')?.addEventListener('click', () => { setWorkflowStage('content'); document.querySelector('#contentInput')?.focus(); });
  document.querySelectorAll('[data-workflow-step]').forEach(btn => btn.addEventListener('click', () => {
    const target = btn.dataset.workflowStep;
    if (target === 'download' && !document.querySelector('#qrCanvas')?.children.length) return;
    if (target === 'design' && workflowStage === 'content') {
      const input = document.querySelector('#contentInput');
      if ((document.querySelector('.type-button.active')?.dataset.type || 'url') === 'url' && input && !input.value.trim()) { input.reportValidity(); return; }
    }
    setWorkflowStage(target);
  }));
  const originalGenerate = qrForm;
  originalGenerate?.addEventListener('submit', () => { setTimeout(() => { if (document.querySelector('#qrCanvas') && !document.querySelector('#qrCanvas').classList.contains('hidden')) setWorkflowStage('download'); }, 80); });
  setWorkflowStage('content');

})();